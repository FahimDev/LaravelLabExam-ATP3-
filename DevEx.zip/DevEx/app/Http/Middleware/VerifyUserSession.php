<?php

namespace App\Http\Middleware;

use Closure;

class VerifyUserSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($req, Closure $next)
    {
        $admin=$req->session()->get('name');
        if(empty($admin)){
            return redirect()->route('login');
        }
        else{
            return $next($req);
        }
       
    }
}

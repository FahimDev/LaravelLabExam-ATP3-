<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<table border="1"  align="center" >
<tr>
			<td>ID</td>
            <td>Product Image</td>
			<td>Product Name</td>
            <td>Price</td>
            <td>Quantity</td>
			<td>Gender</td>
            <td>Catagory</td>
            <td>Age</td>

			<td>ACTION</td>
		</tr>

	 <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($s->id); ?></td>
            <td><img src="uploads/"<?php echo e($s->path); ?> alt=""></td> 
            <td><?php echo e($s->fullName); ?></td>
            <td><?php echo e($s->userName); ?></td>
            <td><?php echo e($s->title); ?></td>
            <td><?php echo e($s->catagory); ?></td>
            <td><?php echo e($s->type); ?></td>
            <td><?php echo e($s->description); ?></td>
            
			
			<td>
				<a href="<?php echo e(route('updateProd', $s->id)); ?>">Edit</a> | 
				<a href="">Delete</a> | 
				<a href="">Details</a>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>
</body>
</html>
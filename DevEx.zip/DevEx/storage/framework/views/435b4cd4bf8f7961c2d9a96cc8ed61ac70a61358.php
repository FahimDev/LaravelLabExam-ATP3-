<?php $__env->startSection('content'); ?>
<table border="1"  align="center" >
		<tr>
			<td>ID</td>
			<td>Employee Name</td>
			<td>Contact</td>

			<td>ACTION</td>
		</tr>

	 <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($s->id); ?></td>
            <td><?php echo e($s->firstName); ?></td>
            <td><?php echo e($s->lastName); ?></td>
            
			
			<td>
				<a href="<?php echo e(route('update', $s->id)); ?>">Edit</a> | 
				<a href="">Delete</a> | 
				<a href="<?php echo e(route('bio', $s->id)); ?>">Details</a>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud.crud', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
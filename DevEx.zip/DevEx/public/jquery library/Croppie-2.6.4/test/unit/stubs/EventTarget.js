EventTarget = function EventTarget() {
	this.addEventListener = function () {
	};
	this.removeEventListener = function () {
	};
	this.dispatchEvent = function () {
	};
};

module.exports = EventTarget;